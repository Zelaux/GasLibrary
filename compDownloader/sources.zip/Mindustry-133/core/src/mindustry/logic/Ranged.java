package mindustry.logic;

import mindustry.gen.*;

public interface Ranged extends Posc, Teamc{
    float range();
}

package arc.func;

public interface Floatc4{
    void get(float x, float y, float x2, float y2);
}

package arc.func;

public interface Boolf<T>{
    boolean get(T t);
}

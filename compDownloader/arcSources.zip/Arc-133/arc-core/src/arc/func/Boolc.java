package arc.func;

public interface Boolc{
    void get(boolean b);
}

package arc.func;

public interface Cons<T>{
    void get(T t);
}

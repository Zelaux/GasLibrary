package arc.func;

public interface Floatp{
    float get();
}

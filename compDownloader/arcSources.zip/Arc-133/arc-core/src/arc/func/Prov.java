package arc.func;

public interface Prov<T>{
    T get();
}

package arc.scene.utils;

public interface Disableable{
    boolean isDisabled();

    void setDisabled(boolean isDisabled);
}

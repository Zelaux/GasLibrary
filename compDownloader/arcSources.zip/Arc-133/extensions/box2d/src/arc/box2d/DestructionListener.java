package arc.box2d;

public interface DestructionListener{

}

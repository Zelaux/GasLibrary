package arc.util;

import arc.graphics.*;
import arc.graphics.g2d.*;
import arc.math.*;
import arc.math.geom.*;

/**
 * Temporary stuff.
 * DO NOT USE IN ANY MULTITHREADED CODE!
 */
public class Tmp{
    public static final Vec2 v1 = new Vec2();
    public static final Vec2 v2 = new Vec2();
    public static final Vec2 v3 = new Vec2();
    public static final Vec2 v4 = new Vec2();
    public static final Vec2 v5 = new Vec2();
    public static final Vec2 v6 = new Vec2();

    public static final Vec3 v31 = new Vec3();
    public static final Vec3 v32 = new Vec3();
    public static final Vec3 v33 = new Vec3();
    public static final Vec3 v34 = new Vec3();

    public static final Rect r1 = new Rect();
    public static final Rect r2 = new Rect();
    public static final Rect r3 = new Rect();

    public static final Circle cr1 = new Circle();
    public static final Circle cr2 = new Circle();
    public static final Circle cr3 = new Circle();

    public static final Vec2 t1 = new Vec2();

    public static final Color c1 = new Color();
    public static final Color c2 = new Color();
    public static final Color c3 = new Color();
    public static final Color c4 = new Color();

    public static final Point2 p1 = new Point2();
    public static final Point2 p2 = new Point2();
    public static final Point2 p3 = new Point2();

    public static final TextureRegion tr1 = new TextureRegion();
    public static final TextureRegion tr2 = new TextureRegion();

    public static final Mat m1 = new Mat();
    public static final Mat m2 = new Mat();
    public static final Mat m3 = new Mat();

    public static final Bezier<Vec2> bz2 = new Bezier<>();
    public static final Bezier<Vec3> bz3 = new Bezier<>();
}

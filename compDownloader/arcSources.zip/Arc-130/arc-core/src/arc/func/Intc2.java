package arc.func;

public interface Intc2{
    void get(int x, int y);
}

package arc.func;

public interface Boolf2<A, B>{
    boolean get(A a, B b);
}

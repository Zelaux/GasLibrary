package arc.scene.event;

public class SceneResizeEvent extends SceneEvent{

}
